/*
* Created By : Scott Register ( registsc )
* File Name : asdf.c
* Creation Date : Sat 12 Oct 2013 12:41:38 PM PDT
* Last Modified : Sat 12 Oct 2013 12:45:40 PM PDT
* Purpose :
*
*/


#include <stdio.h>

struct student
{
	int data;
	int id;
	char name[100];

};


int main(int argc, const char *argv[]){
	struct student s;

}

	int i;
	for (i = ; i < count; i++) {

	

	}
